export const downloadHotelInvoice = (payload) => {
  alert("Hotel invoice coming soon");
};
