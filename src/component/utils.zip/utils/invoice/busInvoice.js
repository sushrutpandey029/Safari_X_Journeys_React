export const downloadBusInvoice = (payload) => {
  alert("Bus invoice coming soon");
};
