export const downloadCabInvoice = (payload) => {
  alert("Cab invoice coming soon");
};
